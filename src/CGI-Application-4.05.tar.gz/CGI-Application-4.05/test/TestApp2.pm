# $Id: TestApp2.pm,v 1.2 2001/05/21 03:49:50 jesse Exp $

package TestApp2;

use strict;

use TestApp;
@TestApp2::ISA = qw(TestApp);

# Test sub-inheritance


1;

