package Default2::empty;
use strict;
use warnings;

=head1 NAME

Default2::empty

=head1 DESCRIPTION

Default2 empty element class for Krang.

=cut


use base 'Krang::ElementClass';

sub new {
   my $pkg = shift;
   my %args = ( name => 'empty',
                @_);
   return $pkg->SUPER::new(%args);
}

sub input_form {
    return '';
}

1;
