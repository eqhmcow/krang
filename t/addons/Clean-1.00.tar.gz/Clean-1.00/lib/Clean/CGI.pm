package Clean::CGI;
use warnings;
use strict;

use base 'Krang::CGI';
use HTML::Clean;

sub cgiapp_postrun {
    my ($self, $o) = @_;
    my $clean = HTML::Clean->new($o, 9);
    $clean->strip();
    my $html  = $clean->data();
    $$o = $$html;
    return;
}

1;
