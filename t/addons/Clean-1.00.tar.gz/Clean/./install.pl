#!/usr/bin/perl -w
use strict;
use warnings;
use Krang::ClassFactory qw(pkg);
use Krang::ClassLoader DB => 'dbh';
use Krang::ClassLoader qw(Conf);

foreach my $instance (pkg('Conf')->instances) {
    pkg('Conf')->instance($instance);
    my $dbh = dbh();
    $dbh->do('CREATE TABLE IF NOT EXISTS cleaned (
                module VARCHAR(255) NOT NULL,
                count  INT NOT NULL DEFAULT 0
              );');
}    
