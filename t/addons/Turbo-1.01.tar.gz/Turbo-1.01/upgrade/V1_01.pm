package V1_01;
use strict;
use warnings;
use base 'Krang::Upgrade';
use Krang::Conf qw(KrangRoot);

sub per_installation {
    system('touch ' . KrangRoot . "/turbo_1.01_was_here");
}

sub per_instance {}

1;
