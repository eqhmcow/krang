package baseC;

sub dummy { 3 };

1;
