package AboutPlus::About;
use strict;
use warnings;

use base 'Krang::CGI::About';
use Krang::ClassLoader Message => 'add_message';

sub setup {
    my $self = shift;
    $self->SUPER::setup();
    $self->run_modes({ barf => 'barf'});
}

sub load_tmpl {
    my $self = shift;
    my $template = $self->SUPER::load_tmpl(@_);
    $template->param(cgi_mode => !$ENV{MOD_PERL});
    return $template;
}

sub show {
    my $self = shift;
    my $output = $self->SUPER::show(@_);
    return $output . 
      "<p>PLUS BIG IMPROVEMENTS!";
}

sub barf {
    my $self = shift;
    my $template = $self->SUPER::load_tmpl('../Workspace/workspace.tmpl');
    add_message('barf');
    add_message('double_barf');

    return $template->output;
}

1;
