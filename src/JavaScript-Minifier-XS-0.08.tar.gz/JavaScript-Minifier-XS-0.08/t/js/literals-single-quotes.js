/* quoted literals get preserved, in several forms */
var single_quoted=' single quoted strings // with line comments ';
