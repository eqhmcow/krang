package Clean::Record;
use strict;
use warnings;

use Krang::ClassLoader 'XML';
use Krang::ClassFactory 'pkg';

sub id_meth { 'record_id' }

sub record_id { shift->{record_id} }

# dummy find method, always returns the same objects
sub find {
    my ($pkg, %args) = @_;

    return 3 if $args{count};
    return (1, 2, 3) if $args{ids_only};
    return (bless({record_id => 1,
                   module    => 'Story',
                   count     => 10
                  },
                  $pkg
                 ),
            bless({record_id => 2,
                   module    => 'Template',
                   count     => 5
                  },
                  $pkg
                 ),
            bless({record_id => 3,
                   module    => 'Media',
                   count     => 3
                  },
                  $pkg
                 ));
}

sub serialize_xml {
    my ($self,   %args) = @_;
    my ($writer, $set)  = @args{qw(writer set)};

    $writer->startTag('record',
                      "xmlns:xsi" =>
                        "http://www.w3.org/2001/XMLSchema-instance",
                      "xsi:noNamespaceSchemaLocation" => 'record.xsd');

    $writer->dataElement($_, $self->{$_}) for qw(record_id module count);
    $writer->endTag('record');
}

sub deserialize_xml {
    my ($pkg, %args) = @_;
    my ($xml, $set, $no_update, $skip_update) =
      @args{qw(xml set no_update skip_update)};

    # parse it up
    my $data = pkg('XML')->simple(xml           => $xml,
                                  suppressempty => 1);

    return
      bless({record_id => $data->{record_id},
             module    => $data->{module},
             count     => $data->{count}
            },
            $pkg);
}

1;
