/* comments get removed */
/*@ except those that are "IE Conditional Compilation" comments @*/
/*@ we'll remove those that start with the flag but don't end with it. */
/* as well as those that end with it but didn't start with it @*/

// line comments also get removed
//@ except those that are "IE Conditional Compilation" line comments
