package baseD;

use base 'baseC';

1;
