#ifndef EBCDIC_H
#define EBCDIC_H  "$Id: ebcdic.h,v 1.3 2001/03/09 10:10:50 martin Exp $"

#include <ap_ebcdic.h>

#endif /*EBCDIC_H*/
