package A::B;

BEGIN {
	$loaded= 1;
}

1;

