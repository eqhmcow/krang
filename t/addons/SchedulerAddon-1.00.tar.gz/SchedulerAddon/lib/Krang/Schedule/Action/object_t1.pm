package Krang::Schedule::Action::object_t1;

use Krang::ClassFactory qw(pkg);
use strict;
use warnings;

use Krang::ClassLoader base => 'Schedule::Action';
use Krang::ClassLoader Log => qw(ASSERT assert critical debug info);
use Carp qw(verbose croak);

sub execute {
    my $self = shift;

    info('object_t1->execute() executing: ' . localtime());
    $self->clean_entry();
}
1;
