package Default2::article2;
use strict;
use warnings;

use base 'Default::article';

sub new {
   my $pkg = shift;
   return $pkg->SUPER::new();
}

1;
