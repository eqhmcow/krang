var trailing="trailing whitespace gets removed";

	
    
