package D;

use Class::Autouse 'C';
use base 'C';

sub method2 { 1 }

1;
