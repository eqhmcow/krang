package T::A;

sub method { 1 }

1;
