package Default2::page;
use strict;
use warnings;

=head1 NAME

Default2::page

=head1 DESCRIPTION

Default2 page element class for Krang. 

=cut


use base 'Krang::ElementClass';

sub new {
   my $pkg = shift;
   my %args = ( name => 'page',
                min  => 1,
                pageable => 1,
                children => 
                [ 
                 Krang::ElementClass::Text->new(name         => "section_header",
                                                display_name => 'Section Header',
                                                ),
                 Krang::ElementClass::Text->new(name         => "large_header",
                                                display_name => 'Large Header',
                                                ),
                 Krang::ElementClass::Textarea->new(name => "paragraph",
                                                    required => 1,
                                                    bulk_edit => 1,
                                                   ),
                 Default2::image->new(),
                 Default2::inset_box->new(), 
                 Krang::ElementClass::MediaLink->new(name => "section_header_image",
                                                     display_name => 'Section Header Image'),
                 Default2::empty->new( name => 'horizontal_line' )

                ],
                @_);
   return $pkg->SUPER::new(%args);
}


1;
