package G;

sub foo { 1 }

1;
