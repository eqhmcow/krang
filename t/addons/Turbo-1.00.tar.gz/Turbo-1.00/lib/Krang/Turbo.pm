package Krang::Turbo;

sub new { bless {}, shift }

1;
