#!/usr/bin/perl
use warnings;
use strict;

my $tmp = $ENV{KRANG_ROOT} . '/tmp/created_by_turbo_postinstall';

`rm -f $tmp`;
