#!/usr/bin/perl
use warnings;
use strict;

my $tmp = $ENV{KRANG_ROOT} . '/tmp/created_by_turbo_postinstall';

print STDERR "sssssssssss $tmp ssssssssssssssssssss\n";

`touch $tmp`;
