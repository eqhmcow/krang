package Krang::Schedule::Action::foobar;

use Krang::ClassFactory qw(pkg);
use strict;
use warnings;

use Krang::ClassLoader base => 'Schedule::Action';
use Krang::ClassLoader Log => qw(ASSERT assert critical debug info);
use Carp qw(verbose croak);

sub execute {
    my $self = shift;

    info('foobar->execute() executing: ' . localtime());
    $self->clean_entry();
}
1;
