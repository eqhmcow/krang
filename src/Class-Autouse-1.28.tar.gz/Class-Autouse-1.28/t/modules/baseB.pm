package baseB;

use base 'baseA';

1;
