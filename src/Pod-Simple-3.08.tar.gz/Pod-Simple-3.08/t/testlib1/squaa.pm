package squaa;

=head1 NAME

squaa -- blorpoesu

=head1 DESCRIPTION

This is just a test file.

=cut

