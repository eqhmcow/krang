# Copyrights 2001-2004,2007 by Mark Overmeer <perl@overmeer.net>.
#  For other contributors see Changes.
# See the manual pages for details on the licensing terms.
# Pod stripped from pm file by OODoc 1.00.
package J;
use vars '$VERSION';
$VERSION = '0.18';

package Another::Class;
use vars '$VERSION';
$VERSION = '0.18';

sub a_method { 42 }

1;

