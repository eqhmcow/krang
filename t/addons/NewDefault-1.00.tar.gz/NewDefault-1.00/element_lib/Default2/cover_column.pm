package Default2::cover_column;
use strict;
use warnings;

=head1 NAME

Default2::cover_column

=head1 DESCRIPTION

Default2 cover_column element class for Krang. 

=cut


use base 'Krang::ElementClass';

sub new {
   my $pkg = shift;
   my %args = ( name => 'cover_column',
                min  => 1,
                children => 
                [ 
                 Krang::ElementClass::Text->new(name         => "section_header" ),
                 Krang::ElementClass::Text->new(name         => "large_header" ),
                 Krang::ElementClass::Textarea->new(name => "paragraph",
                                                    required => 1,
                                                    bulk_edit => 1,
                                                   ),
                 Krang::ElementClass::MediaLink->new(name => "header_image" ),
                 Default2::lead_in->new(),
                 Default2::external_lead_in->new(),
                 Default2::image->new(),
                 Default2::empty->new( name => "horizontal_line" ),
                ],
                @_);
   return $pkg->SUPER::new(%args);
}


1;
